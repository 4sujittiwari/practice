from pywebostv.discovery import *    # Because I'm lazy, don't do this.
from pywebostv.connection import *
from pywebostv.controls import *


class volume:
    def up(self, client):
        media = MediaControl(client)
        media.volume_up()

    def down(self, client):
        media = MediaControl(client)
        media.volume_down()

    def mute(self, client):
        media = MediaControl(client)
        media.mute(True)

    def unmute(self, client):
        media = MediaControl(client)
        media.mute(False)        

