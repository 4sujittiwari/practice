from pywebostv.discovery import *    # Because I'm lazy, don't do this.
from pywebostv.connection import *
from pywebostv.controls import *


class buttons:
    def up(self, client):
        inp = InputControl(client)
        inp.connect_input()
        inp.up()

    def down(self, client):
        inp = InputControl(client)
        inp.connect_input()
        inp.down()

    def right(self, client):
        inp = InputControl(client)
        inp.connect_input()
        inp.right()

    def left(self, client):
        inp = InputControl(client)
        inp.connect_input()
        inp.left()
    
    def ok(self, client):
        inp = InputControl(client)
        inp.connect_input()
        inp.ok()

    def play(self, client):
        media = MediaControl(client)
        media.play()
    
    def pause(self, client):
        media = MediaControl(client)
        media.pause()

