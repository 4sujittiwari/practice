import pickle
import os

class fileUtil:
    def readFile(self, filePath):
        print("reading file")
        store = {}
        if os.path.getsize(filePath) > 0:
            with open(filePath, 'rb') as storeObject:
                store = pickle.load(storeObject) 
        return store

    def writeFile(self, filePath, store):
        with open(filePath, 'wb') as storeObject:
            pickle.dump(store, storeObject)