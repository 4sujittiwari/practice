from flask import Flask, escape, request
from discover import discoverTv
from power import *
from volume import *


app = Flask(__name__)
@app.route('/detect')
def hello():
    name = request.args.get("name", "World")
    return f'Hello, {escape(name)}!'

@app.route('/off')
def off():
    client = discoverTv().find()
    power().off(client)
    return "abc"

@app.route('/volumeup')
def volumeup():
    client = discoverTv().find()
    volume().up(client)
    return "abc"

@app.route('/volumedown')
def volumedown():
    client = discoverTv().find()
    volume().down(client)
    return "abc"    

@app.route('/mute')
def mute():
    client = discoverTv().find()
    volume().mute(client)
    return "abc" 

@app.route('/unmute')
def unmute():
    client = discoverTv().find()
    volume().unmute(client)
    return "abc" 