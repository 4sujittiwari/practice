from flask import Flask, escape, request
from discover import discoverTv
from power import *
from volume import *
from buttons import *


app = Flask(__name__)
@app.route('/detect')
def hello():
    name = request.args.get("name", "World")
    return f'Hello, {escape(name)}!'

@app.route('/off')
def off():
    client = discoverTv().find()
    power().off(client)
    return "abc"

@app.route('/volumeup')
def volumeup():
    client = discoverTv().find()
    volume().up(client)
    return "abc"

@app.route('/volumedown')
def volumedown():
    client = discoverTv().find()
    volume().down(client)
    return "abc"    

@app.route('/mute')
def mute():
    client = discoverTv().find()
    volume().mute(client)
    return "abc" 

@app.route('/unmute')
def unmute():
    client = discoverTv().find()
    volume().unmute(client)
    return "abc" 

@app.route('/up')
def up():
    client = discoverTv().find()
    buttons().up(client)
    return "abc"     

@app.route('/down')
def down():
    client = discoverTv().find()
    buttons().down(client)
    return "abc"   

@app.route('/right')
def right():
    client = discoverTv().find()
    buttons().right(client)
    return "abc"   
    
@app.route('/left')
def left():
    client = discoverTv().find()
    buttons().left(client)
    return "abc"   
    
@app.route('/play')
def play():
    client = discoverTv().find()
    buttons().play(client)
    return "abc"   
    
@app.route('/pause')
def pause():
    client = discoverTv().find()
    buttons().pause(client)
    return "abc"   
    
@app.route('/ok')
def ok():
    client = discoverTv().find()
    buttons().ok(client)
    return "abc"   
    
       