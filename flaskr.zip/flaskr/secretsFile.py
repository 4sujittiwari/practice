from fileUtil import fileUtil
class secretsFile:
    def checkForSecrets(self):
        authKey = fileUtil().readFile("secrets.obj")
        return authKey

    def getSecrets(self):
        authKey = fileUtil().readFile("secrets.obj")
        return authKey

    def addSecrets(self, key):
        fileUtil().writeFile("secrets.obj", key)
