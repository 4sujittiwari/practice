from pywebostv.discovery import *    # Because I'm lazy, don't do this.
from pywebostv.connection import *
from pywebostv.controls import *
from secretsFile import *

class power:
    def off(self, client):
        system = SystemControl(client)
        system.power_off()


