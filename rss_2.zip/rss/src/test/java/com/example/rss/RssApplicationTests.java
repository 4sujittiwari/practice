package com.example.rss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RssApplicationTests {

	@Test
	void contextLoads() {
	}

}
